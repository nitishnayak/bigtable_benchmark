# Google Bigtable Benchmark Kit

This package contains Python scripts and JSON reports for a
Google Cloud Bigtable benchmarking demonstration.

## Contents

- scripts/: benchmark scripts and helper utilities
- reports/: saved JSON benchmark results

## Prerequisites

- A Google Cloud project with a Bigtable instance and table
- Python 3.12 or a compatible Python version
- Google Cloud CLI
- Permissions to access the target Bigtable instance and table

## Setup

Create and activate a virtual environment:

```bash
python3 -m venv bigtable-bench-venv
source bigtable-bench-venv/bin/activate
pip install --upgrade pip
pip install google-cloud-bigtable google-auth
```

Authenticate with Google Cloud:

```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
gcloud auth application-default login
```

Update PROJECT_ID, INSTANCE_ID, and TABLE_ID in the scripts
if your environment uses different names.

## Run a benchmark

From the directory containing the scripts, for example:

```bash
python benchmark_reads_direct.py
python benchmark_writes.py
python benchmark_reads_concurrent.py
python benchmark_writes_concurrent.py
python benchmark_mixed_workload.py
python benchmark_reads_scaling.py
```

Check each script's configuration and output filename before running.

## Important notes

- Run scripts only against a project and Bigtable resources you are
  authorized to use.
- Writes create or modify rows and may incur Google Cloud charges.
- Seed scripts may write many rows; inspect their configuration first.
- Results depend on client, network, workload, table design,
  cluster configuration, and resource utilization.
- Small benchmark results do not establish maximum capacity or
  production readiness.
- JSON reports are historical results from the original test
  environment. Re-running a benchmark may produce different results.
