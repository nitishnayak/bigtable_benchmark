
import json
import random
import time
import statistics
import threading
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

import google.auth
from google.cloud.bigtable_v2 import BigtableClient
from google.cloud.bigtable_v2.types import ReadRowsRequest

PROJECT_ID = "bigtable-benchmark-lab"
INSTANCE_ID = "bt-benchmark-lab"
TABLE_ID = "benchmark-table"

TOTAL_READS = 100
WORKERS = 10
TOTAL_ROWS = 10_000

TABLE_NAME = (
    f"projects/{PROJECT_ID}/instances/"
    f"{INSTANCE_ID}/tables/{TABLE_ID}"
)

_thread_local = threading.local()
_all_clients = []
_clients_lock = threading.Lock()


def percentile(values, p):
    if not values:
        return None

    ordered = sorted(values)
    index = max(
        0,
        min(
            len(ordered) - 1,
            int((p / 100) * len(ordered) + 0.999999) - 1,
        ),
    )
    return round(ordered[index], 3)


def get_worker_client(credentials):
    # Create one client per worker thread, then reuse it.
    if not hasattr(_thread_local, "client"):
        client = BigtableClient(credentials=credentials)
        _thread_local.client = client

        with _clients_lock:
            _all_clients.append(client)

    return _thread_local.client


def main():
    credentials, _ = google.auth.default()

    def read_one(key):
        client = get_worker_client(credentials)
        start = time.perf_counter()

        try:
            request = ReadRowsRequest(
                table_name=TABLE_NAME,
                rows={"row_keys": [key]},
            )

            found = False
            returned_key = None

            for response in client.read_rows(request=request):
                for chunk in response.chunks:
                    if chunk.row_key:
                        returned_key = chunk.row_key
                    if chunk.commit_row:
                        found = True

            latency_ms = (time.perf_counter() - start) * 1000

            return {
                "ok": found and returned_key == key,
                "latency_ms": latency_ms,
                "error": None,
            }

        except Exception as exc:
            return {
                "ok": False,
                "latency_ms": (time.perf_counter() - start) * 1000,
                "error": str(exc),
            }

    keys = [
        f"bench#{i:010d}".encode()
        for i in range(TOTAL_ROWS)
    ]

    random.seed(42)
    random.shuffle(keys)
    keys = keys[:TOTAL_READS]

    print(
        f"Starting {TOTAL_READS} reads with {WORKERS} workers...",
        flush=True,
    )

    latencies = []
    errors = 0
    missing = 0
    start = time.perf_counter()

    try:
        with ThreadPoolExecutor(max_workers=WORKERS) as executor:
            futures = [
                executor.submit(read_one, key)
                for key in keys
            ]

            for future in as_completed(futures):
                result = future.result()

                if result["ok"]:
                    latencies.append(result["latency_ms"])
                elif result["error"]:
                    errors += 1
                    print("Read error:", result["error"], flush=True)
                else:
                    missing += 1

        elapsed = time.perf_counter() - start
        successful = len(latencies)

        report = {
            "scenario": "direct_api_concurrent_point_reads_reused_clients",
            "project_id": PROJECT_ID,
            "table": TABLE_NAME,
            "scheduled_reads": TOTAL_READS,
            "workers": WORKERS,
            "successful_reads": successful,
            "missing_rows": missing,
            "errors": errors,
            "elapsed_seconds": round(elapsed, 3),
            "successful_reads_per_second": (
                round(successful / elapsed, 2) if elapsed else 0
            ),
            "average_latency_ms": (
                round(statistics.mean(latencies), 3)
                if latencies else None
            ),
            "p50_latency_ms": percentile(latencies, 50),
            "p95_latency_ms": percentile(latencies, 95),
            "p99_latency_ms": percentile(latencies, 99),
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        }

        with open(
            "concurrent_read_benchmark_report.json", "w"
        ) as file:
            json.dump(report, file, indent=2)

        print("\nCONCURRENT READ RESULTS", flush=True)
        print(json.dumps(report, indent=2), flush=True)
        print(
            "\nReport saved to: concurrent_read_benchmark_report.json",
            flush=True,
        )

    finally:
        for client in _all_clients:
            client.transport.close()


if __name__ == "__main__":
    main()
