import json
import random
import statistics
import threading
import time
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

import google.auth
from google.cloud.bigtable_v2 import BigtableClient
from google.cloud.bigtable_v2.types import ReadRowsRequest

PROJECT_ID = "bigtable-benchmark-lab"
INSTANCE_ID = "bt-benchmark-lab"
TABLE_ID = "benchmark-table"

WORKER_LEVELS = [1, 5, 10, 20]
WARMUP_READS = 20
READS_PER_RUN = 200
REPEATS = 3
TOTAL_ROWS = 10_000

TABLE_NAME = (
    f"projects/{PROJECT_ID}/instances/"
    f"{INSTANCE_ID}/tables/{TABLE_ID}"
)


def percentile(values, p):
    if not values:
        return None
    ordered = sorted(values)
    index = max(
        0,
        min(len(ordered) - 1,
            int((p / 100) * len(ordered) + 0.999999) - 1),
    )
    return round(ordered[index], 3)


def main():
    credentials, _ = google.auth.default()
    all_results = []

    def make_keys(count, seed):
        rng = random.Random(seed)
        indexes = [rng.randrange(TOTAL_ROWS) for _ in range(count)]
        return [f"bench#{i:010d}".encode() for i in indexes]

    for workers in WORKER_LEVELS:
        print(f"\n=== Testing {workers} worker(s) ===", flush=True)

        local = threading.local()
        clients = []
        clients_lock = threading.Lock()

        def get_client():
            if not hasattr(local, "client"):
                client = BigtableClient(credentials=credentials)
                local.client = client
                with clients_lock:
                    clients.append(client)
            return local.client

        def read_one(key):
            client = get_client()
            start = time.perf_counter()
            try:
                request = ReadRowsRequest(
                    table_name=TABLE_NAME,
                    rows={"row_keys": [key]},
                )
                found = False
                returned_key = None

                for response in client.read_rows(request=request):
                    for chunk in response.chunks:
                        if chunk.row_key:
                            returned_key = chunk.row_key
                        if chunk.commit_row:
                            found = True

                latency_ms = (time.perf_counter() - start) * 1000
                return {
                    "ok": found and returned_key == key,
                    "latency_ms": latency_ms,
                    "error": None,
                }
            except Exception as exc:
                return {
                    "ok": False,
                    "latency_ms": (time.perf_counter() - start) * 1000,
                    "error": str(exc),
                }

        try:
            with ThreadPoolExecutor(max_workers=workers) as executor:
                # Warm-up requests are excluded from measured results.
                warmup_keys = make_keys(WARMUP_READS, 1000 + workers)
                warmup_results = list(
                    executor.map(read_one, warmup_keys)
                )
                warmup_failures = sum(
                    not result["ok"] for result in warmup_results
                )
                print(
                    f"Warm-up complete: {WARMUP_READS} requests; "
                    f"{warmup_failures} failures",
                    flush=True,
                )

                for run_number in range(1, REPEATS + 1):
                    keys = make_keys(
                        READS_PER_RUN,
                        10000 + workers * 100 + run_number,
                    )
                    latencies = []
                    errors = 0
                    missing = 0
                    start = time.perf_counter()

                    futures = [
                        executor.submit(read_one, key) for key in keys
                    ]
                    for future in as_completed(futures):
                        result = future.result()
                        if result["ok"]:
                            latencies.append(result["latency_ms"])
                        elif result["error"]:
                            errors += 1
                            print(
                                f"Read error (run {run_number}): "
                                f"{result['error']}",
                                flush=True,
                            )
                        else:
                            missing += 1

                    elapsed = time.perf_counter() - start
                    successful = len(latencies)

                    report = {
                        "workers": workers,
                        "run": run_number,
                        "scheduled_reads": READS_PER_RUN,
                        "successful_reads": successful,
                        "missing_rows": missing,
                        "errors": errors,
                        "elapsed_seconds": round(elapsed, 3),
                        "successful_reads_per_second": (
                            round(successful / elapsed, 2)
                            if elapsed else 0
                        ),
                        "average_latency_ms": (
                            round(statistics.mean(latencies), 3)
                            if latencies else None
                        ),
                        "p50_latency_ms": percentile(latencies, 50),
                        "p95_latency_ms": percentile(latencies, 95),
                        "p99_latency_ms": percentile(latencies, 99),
                        "warmup_failures": warmup_failures,
                        "completed_at_utc": (
                            datetime.now(timezone.utc).isoformat()
                        ),
                    }
                    all_results.append(report)
                    print(json.dumps(report, indent=2), flush=True)

        finally:
            for client in clients:
                client.transport.close()

    output = {
        "scenario": "bigtable_point_read_worker_scaling",
        "project_id": PROJECT_ID,
        "table": TABLE_NAME,
        "worker_levels": WORKER_LEVELS,
        "warmup_reads_per_level": WARMUP_READS,
        "reads_per_run": READS_PER_RUN,
        "repeats_per_level": REPEATS,
        "results": all_results,
    }

    with open(
        "bigtable_read_scaling_report.json", "w"
    ) as file:
        json.dump(output, file, indent=2)

    print("\n=== SCALING TEST COMPLETE ===", flush=True)
    print("Report saved to: bigtable_read_scaling_report.json")

    print("\n=== THROUGHPUT SUMMARY ===")
    for workers in WORKER_LEVELS:
        runs = [r for r in all_results if r["workers"] == workers]
        rates = [r["successful_reads_per_second"] for r in runs]
        print(
            f"{workers:>2} workers: "
            f"run rates={rates}; "
            f"average={statistics.mean(rates):.2f} reads/sec"
        )


if __name__ == "__main__":
    main()

