
import json
import random
import time
import statistics
from datetime import datetime, timezone

import google.auth
from google.cloud.bigtable_v2 import BigtableClient
from google.cloud.bigtable_v2.types import ReadRowsRequest

PROJECT_ID = "bigtable-benchmark-lab"
INSTANCE_ID = "bt-benchmark-lab"
TABLE_ID = "benchmark-table"

TABLE_NAME = (
    f"projects/{PROJECT_ID}/instances/"
    f"{INSTANCE_ID}/tables/{TABLE_ID}"
)

TOTAL_READS = 100
TOTAL_ROWS = 10_000

def percentile(values, p):
    if not values:
        return None

    ordered = sorted(values)
    index = max(
        0,
        min(len(ordered) - 1, int((p / 100) * len(ordered) + 0.999999) - 1),
    )
    return round(ordered[index], 3)


def main():
    credentials, _ = google.auth.default()
    client = BigtableClient(credentials=credentials)

    keys = [
        f"bench#{i:010d}".encode()
        for i in range(TOTAL_ROWS)
    ]

    random.seed(42)
    random.shuffle(keys)

    latencies = []
    errors = 0
    missing = 0

    print(f"Starting {TOTAL_READS} sequential point reads...", flush=True)

    benchmark_start = time.perf_counter()

    for i, key in enumerate(keys[:TOTAL_READS], start=1):
        request = ReadRowsRequest(
            table_name=TABLE_NAME,
            rows={"row_keys": [key]},
        )

        read_start = time.perf_counter()

        try:
            found = False
            returned_key = None

            # Consume the complete streaming response.
            for response in client.read_rows(request=request):
                for chunk in response.chunks:
                    if chunk.row_key:
                        returned_key = chunk.row_key

                    if chunk.commit_row:
                        found = True

            latency_ms = (time.perf_counter() - read_start) * 1000
            latencies.append(latency_ms)

            if not found or returned_key != key:
                missing += 1

            if i % 20 == 0:
                print(f"Completed {i}/{TOTAL_READS} reads", flush=True)

        except Exception as exc:
            errors += 1
            print(f"Read {i} failed: {exc}", flush=True)

    elapsed = time.perf_counter() - benchmark_start
    successful = TOTAL_READS - errors - missing

    report = {
        "scenario": "direct_api_sequential_point_reads",
        "project_id": PROJECT_ID,
        "table": TABLE_NAME,
        "scheduled_reads": TOTAL_READS,
        "successful_reads": successful,
        "missing_rows": missing,
        "errors": errors,
        "elapsed_seconds": round(elapsed, 3),
        "successful_reads_per_second": (
            round(successful / elapsed, 2) if elapsed else 0
        ),
        "average_latency_ms": (
            round(statistics.mean(latencies), 3) if latencies else None
        ),
        "p50_latency_ms": percentile(latencies, 50),
        "p95_latency_ms": percentile(latencies, 95),
        "p99_latency_ms": percentile(latencies, 99),
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }

    report_file = "read_benchmark_report.json"

    with open(report_file, "w") as file:
        json.dump(report, file, indent=2)

    print("\nREAD BENCHMARK RESULTS")
    print(json.dumps(report, indent=2))
    print(f"\nReport saved to: {report_file}")

    client.transport.close()


if __name__ == "__main__":
    main()
