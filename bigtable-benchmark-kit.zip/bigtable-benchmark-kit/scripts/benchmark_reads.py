import json
import random
import time
import statistics
from datetime import datetime, timezone

from google.cloud import bigtable

PROJECT_ID = "bigtable-benchmark-lab"
INSTANCE_ID = "bt-benchmark-lab"
TABLE_ID = "benchmark-table"

TOTAL_READS = 100
WARMUP_READS = 5

client = bigtable.Client(project=PROJECT_ID, admin=False)
table = client.instance(INSTANCE_ID).table(TABLE_ID)

# Workaround: disable the client's background metrics exporter for this run.
# This does not disable Cloud Monitoring or change authentication.
data_client = client._veneer_data_client
for handler in list(data_client._metrics.handlers):
    try:
        handler.close()
    except Exception as exc:
        print(f"Metrics handler shutdown warning: {exc}", flush=True)
data_client._metrics.handlers.clear()

keys = [
    f"bench#{i:010d}".encode()
    for i in range(10_000)
]
random.seed(42)
random.shuffle(keys)

latencies_ms = []
errors = 0
missing_rows = 0

def read_one(key):
    row = table.read_row(key)
    if row is None:
        return False
    return True

print(f"Warm-up: {WARMUP_READS} point reads...", flush=True)
for i in range(WARMUP_READS):
    try:
        read_one(keys[i % len(keys)])
    except Exception as exc:
        print(f"Warm-up error: {exc}", flush=True)

print(f"Starting measured run: {TOTAL_READS} point reads", flush=True)
start = time.perf_counter()

for i in range(TOTAL_READS):
    key = keys[i % len(keys)]
    t0 = time.perf_counter()
    try:
        found = read_one(key)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        latencies_ms.append(elapsed_ms)
        if not found:
            missing_rows += 1
    except Exception as exc:
        errors += 1
        print(f"Read error at operation {i}: {exc}", flush=True)

total_seconds = time.perf_counter() - start

def percentile(values, p):
    if not values:
        return None
    values = sorted(values)
    idx = max(0, min(len(values) - 1, int((p / 100) * len(values) + 0.999999) - 1))
    return round(values[idx], 3)

successful_reads = len(latencies_ms) - missing_rows
report = {
    "scenario": "single-threaded_random_point_reads",
    "project_id": PROJECT_ID,
    "instance_id": INSTANCE_ID,
    "table_id": TABLE_ID,
    "scheduled_reads": TOTAL_READS,
    "successful_reads": successful_reads,
    "missing_rows": missing_rows,
    "errors": errors,
    "elapsed_seconds": round(total_seconds, 3),
    "successful_reads_per_second": round(successful_reads / total_seconds, 2),
    "average_latency_ms": round(statistics.mean(latencies_ms), 3) if latencies_ms else None,
    "p50_latency_ms": percentile(latencies_ms, 50),
    "p95_latency_ms": percentile(latencies_ms, 95),
    "p99_latency_ms": percentile(latencies_ms, 99),
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
}

with open("read_benchmark_report.json", "w") as f:
    json.dump(report, f, indent=2)

print("\nREAD BENCHMARK RESULTS")
print(json.dumps(report, indent=2))
print("\nNote: This is a single-threaded baseline, not maximum Bigtable capacity.")
