import json
import time
import uuid
from datetime import datetime, timezone

from google.cloud import bigtable
from google.cloud.bigtable.batcher import MutationsBatcher

PROJECT_ID = "bigtable-benchmark-lab"
INSTANCE_ID = "bt-benchmark-lab"
TABLE_ID = "benchmark-table"

TOTAL_ROWS = 10_000
BATCH_SIZE = 100
PAYLOAD_SIZE = 512

run_id = str(uuid.uuid4())
client = bigtable.Client(project=PROJECT_ID, admin=False)
table = client.instance(INSTANCE_ID).table(TABLE_ID)

start = time.perf_counter()
print(f"Starting seed: {TOTAL_ROWS} rows; run_id={run_id}", flush=True)

with MutationsBatcher(table, flush_count=BATCH_SIZE) as batcher:
    for i in range(TOTAL_ROWS):
        row_key = f"bench#{i:010d}"
        row = table.direct_row(row_key.encode("utf-8"))
        row.set_cell("cf1", "payload", b"x" * PAYLOAD_SIZE)
        row.set_cell("cf1", "run_id", run_id.encode("utf-8"))
        row.set_cell(
            "cf1",
            "created_at",
            datetime.now(timezone.utc).isoformat().encode("utf-8"),
        )
        batcher.mutate(row)

        if (i + 1) % 1000 == 0:
            elapsed = time.perf_counter() - start
            print(
                f"Submitted {i + 1}/{TOTAL_ROWS} rows "
                f"in {elapsed:.2f}s",
                flush=True,
            )

elapsed = time.perf_counter() - start
report = {
    "run_id": run_id,
    "project_id": PROJECT_ID,
    "instance_id": INSTANCE_ID,
    "table_id": TABLE_ID,
    "rows_submitted": TOTAL_ROWS,
    "payload_size_bytes": PAYLOAD_SIZE,
    "elapsed_seconds": round(elapsed, 3),
    "submission_rate_rows_per_second": round(TOTAL_ROWS / elapsed, 2),
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
}

with open("seed_report.json", "w") as f:
    json.dump(report, f, indent=2)

print("\nSeed operation completed without a reported exception.")
print(json.dumps(report, indent=2))
print("Note: submission rate is not a verified Bigtable write-throughput metric.")
