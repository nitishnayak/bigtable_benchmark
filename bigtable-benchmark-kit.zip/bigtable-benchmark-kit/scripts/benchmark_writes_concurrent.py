
import json
import time
import statistics
import threading
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

import google.auth
from google.cloud.bigtable_v2 import BigtableClient
from google.cloud.bigtable_v2.types import (
    MutateRowsRequest,
    Mutation,
)

PROJECT_ID = "bigtable-benchmark-lab"
INSTANCE_ID = "bt-benchmark-lab"
TABLE_ID = "benchmark-table"

TOTAL_WRITES = 100
WORKERS = 10
PAYLOAD_SIZE = 512

TABLE_NAME = (
    f"projects/{PROJECT_ID}/instances/"
    f"{INSTANCE_ID}/tables/{TABLE_ID}"
)

_thread_local = threading.local()
_all_clients = []
_clients_lock = threading.Lock()


def percentile(values, p):
    if not values:
        return None

    ordered = sorted(values)
    index = max(
        0,
        min(
            len(ordered) - 1,
            int((p / 100) * len(ordered) + 0.999999) - 1,
        ),
    )
    return round(ordered[index], 3)


def get_worker_client(credentials):
    # Each worker creates a client once and reuses it.
    if not hasattr(_thread_local, "client"):
        client = BigtableClient(credentials=credentials)
        _thread_local.client = client

        with _clients_lock:
            _all_clients.append(client)

    return _thread_local.client


def main():
    credentials, _ = google.auth.default()
    payload = b"x" * PAYLOAD_SIZE

    def write_one(index):
        client = get_worker_client(credentials)
        row_key = f"concurrentwrite#{index:010d}".encode()

        mutation = Mutation(
            set_cell=Mutation.SetCell(
                family_name="cf1",
                column_qualifier=b"payload",
                value=payload,
            )
        )

        request = MutateRowsRequest(
            table_name=TABLE_NAME,
            entries=[
                MutateRowsRequest.Entry(
                    row_key=row_key,
                    mutations=[mutation],
                )
            ],
        )

        start = time.perf_counter()

        try:
            # MutateRows returns per-entry statuses.
            responses = list(client.mutate_rows(request=request))

            latency_ms = (time.perf_counter() - start) * 1000

            success = (
                len(responses) == 1
                and len(responses[0].entries) == 1
                and responses[0].entries[0].status.code == 0
            )

            error = None
            if not success:
                error = (
                    "Write response was not successful: "
                    + str(responses)
                )

            return {
                "ok": success,
                "latency_ms": latency_ms,
                "error": error,
                "row_key": row_key.decode(),
            }

        except Exception as exc:
            return {
                "ok": False,
                "latency_ms": (time.perf_counter() - start) * 1000,
                "error": str(exc),
                "row_key": row_key.decode(),
            }

    print(
        f"Starting {TOTAL_WRITES} writes with {WORKERS} workers...",
        flush=True,
    )

    latencies = []
    errors = 0
    start = time.perf_counter()

    try:
        with ThreadPoolExecutor(max_workers=WORKERS) as executor:
            futures = [
                executor.submit(write_one, i)
                for i in range(TOTAL_WRITES)
            ]

            for future in as_completed(futures):
                result = future.result()

                if result["ok"]:
                    latencies.append(result["latency_ms"])
                else:
                    errors += 1
                    print(
                        "Write error:",
                        result["row_key"],
                        result["error"],
                        flush=True,
                    )

        elapsed = time.perf_counter() - start
        successful = len(latencies)

        report = {
            "scenario": "direct_api_concurrent_point_writes_reused_clients",
            "project_id": PROJECT_ID,
            "table": TABLE_NAME,
            "scheduled_writes": TOTAL_WRITES,
            "workers": WORKERS,
            "payload_bytes_per_write": PAYLOAD_SIZE,
            "successful_writes": successful,
            "errors": errors,
            "elapsed_seconds": round(elapsed, 3),
            "successful_writes_per_second": (
                round(successful / elapsed, 2) if elapsed else 0
            ),
            "average_latency_ms": (
                round(statistics.mean(latencies), 3)
                if latencies else None
            ),
            "p50_latency_ms": percentile(latencies, 50),
            "p95_latency_ms": percentile(latencies, 95),
            "p99_latency_ms": percentile(latencies, 99),
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        }

        with open(
            "concurrent_write_benchmark_report.json", "w"
        ) as file:
            json.dump(report, file, indent=2)

        print("\nCONCURRENT WRITE RESULTS", flush=True)
        print(json.dumps(report, indent=2), flush=True)
        print(
            "\nReport saved to: concurrent_write_benchmark_report.json",
            flush=True,
        )

    finally:
        for client in _all_clients:
            client.transport.close()


if __name__ == "__main__":
    main()
