
import json
import time
import statistics
import threading
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

import google.auth
from google.cloud.bigtable_v2 import BigtableClient
from google.cloud.bigtable_v2.types import (
    ReadRowsRequest,
    MutateRowsRequest,
    Mutation,
)

PROJECT_ID = "bigtable-benchmark-lab"
INSTANCE_ID = "bt-benchmark-lab"
TABLE_ID = "benchmark-table"

TOTAL_READS = 50
TOTAL_WRITES = 50
WORKERS = 10
PAYLOAD_SIZE = 512

TABLE_NAME = (
    f"projects/{PROJECT_ID}/instances/"
    f"{INSTANCE_ID}/tables/{TABLE_ID}"
)

_thread_local = threading.local()
_all_clients = []
_clients_lock = threading.Lock()


def percentile(values, p):
    if not values:
        return None

    ordered = sorted(values)
    index = max(
        0,
        min(
            len(ordered) - 1,
            int((p / 100) * len(ordered) + 0.999999) - 1,
        ),
    )
    return round(ordered[index], 3)


def get_worker_client(credentials):
    # One reusable client per worker thread.
    if not hasattr(_thread_local, "client"):
        client = BigtableClient(credentials=credentials)
        _thread_local.client = client

        with _clients_lock:
            _all_clients.append(client)

    return _thread_local.client


def read_one(client, index):
    key = f"bench#{index:010d}".encode()
    request = ReadRowsRequest(
        table_name=TABLE_NAME,
        rows={"row_keys": [key]},
    )

    start = time.perf_counter()

    try:
        found = False
        returned_key = None

        for response in client.read_rows(request=request):
            for chunk in response.chunks:
                if chunk.row_key:
                    returned_key = chunk.row_key
                if chunk.commit_row:
                    found = True

        latency = (time.perf_counter() - start) * 1000
        success = found and returned_key == key

        return {
            "operation": "read",
            "ok": success,
            "latency_ms": latency,
            "error": None if success else "Row missing or incomplete",
        }

    except Exception as exc:
        return {
            "operation": "read",
            "ok": False,
            "latency_ms": (time.perf_counter() - start) * 1000,
            "error": str(exc),
        }


def write_one(client, index):
    key = f"mixedwrite#{index:010d}".encode()
    payload = b"x" * PAYLOAD_SIZE

    mutation = Mutation(
        set_cell=Mutation.SetCell(
            family_name="cf1",
            column_qualifier=b"payload",
            value=payload,
        )
    )

    request = MutateRowsRequest(
        table_name=TABLE_NAME,
        entries=[
            MutateRowsRequest.Entry(
                row_key=key,
                mutations=[mutation],
            )
        ],
    )

    start = time.perf_counter()

    try:
        responses = list(client.mutate_rows(request=request))
        latency = (time.perf_counter() - start) * 1000

        success = (
            len(responses) == 1
            and len(responses[0].entries) == 1
            and responses[0].entries[0].status.code == 0
        )

        return {
            "operation": "write",
            "ok": success,
            "latency_ms": latency,
            "error": None if success else str(responses),
        }

    except Exception as exc:
        return {
            "operation": "write",
            "ok": False,
            "latency_ms": (time.perf_counter() - start) * 1000,
            "error": str(exc),
        }


def main():
    credentials, _ = google.auth.default()

    tasks = (
        [("read", i) for i in range(TOTAL_READS)]
        + [("write", i) for i in range(TOTAL_WRITES)]
    )

    # Alternate reads and writes in the submission list.
    tasks.sort(key=lambda item: item[1] * 2 + (item[0] == "write"))

    print(
        f"Starting mixed workload: {TOTAL_READS} reads, "
        f"{TOTAL_WRITES} writes, {WORKERS} workers...",
        flush=True,
    )

    results = []
    start = time.perf_counter()

    def run_task(task):
        operation, index = task
        client = get_worker_client(credentials)

        if operation == "read":
            return read_one(client, index)
        return write_one(client, index)

    try:
        with ThreadPoolExecutor(max_workers=WORKERS) as executor:
            futures = [
                executor.submit(run_task, task)
                for task in tasks
            ]

            for future in as_completed(futures):
                result = future.result()
                results.append(result)

                if not result["ok"]:
                    print(
                        f"{result['operation'].upper()} ERROR:",
                        result["error"],
                        flush=True,
                    )

        elapsed = time.perf_counter() - start

        read_results = [
            r for r in results if r["operation"] == "read"
        ]
        write_results = [
            r for r in results if r["operation"] == "write"
        ]

        def summarize(items):
            latencies = [
                r["latency_ms"] for r in items if r["ok"]
            ]
            successful = len(latencies)
            scheduled = len(items)

            return {
                "scheduled": scheduled,
                "successful": successful,
                "errors_or_missing": scheduled - successful,
                "successful_per_second": (
                    round(successful / elapsed, 2)
                    if elapsed else 0
                ),
                "average_latency_ms": (
                    round(statistics.mean(latencies), 3)
                    if latencies else None
                ),
                "p50_latency_ms": percentile(latencies, 50),
                "p95_latency_ms": percentile(latencies, 95),
                "p99_latency_ms": percentile(latencies, 99),
            }

        successful_total = sum(
            1 for result in results if result["ok"]
        )

        report = {
            "scenario": "direct_api_mixed_concurrent_reads_writes",
            "project_id": PROJECT_ID,
            "table": TABLE_NAME,
            "workers": WORKERS,
            "total_operations_scheduled": len(tasks),
            "total_operations_successful": successful_total,
            "total_operations_failed": len(tasks) - successful_total,
            "elapsed_seconds": round(elapsed, 3),
            "total_successful_operations_per_second": (
                round(successful_total / elapsed, 2)
                if elapsed else 0
            ),
            "reads": summarize(read_results),
            "writes": summarize(write_results),
            "payload_bytes_per_write": PAYLOAD_SIZE,
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        }

        with open("mixed_workload_report.json", "w") as file:
            json.dump(report, file, indent=2)

        print("\nMIXED WORKLOAD RESULTS")
        print(json.dumps(report, indent=2))
        print("\nReport saved to: mixed_workload_report.json")

    finally:
        for client in _all_clients:
            client.transport.close()


if __name__ == "__main__":
    main()
