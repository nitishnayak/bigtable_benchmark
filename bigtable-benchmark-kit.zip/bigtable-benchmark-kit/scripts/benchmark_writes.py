
import json
import time
import statistics
from datetime import datetime, timezone

import google.auth
from google.cloud.bigtable_v2 import BigtableClient
from google.cloud.bigtable_v2.types import MutateRowsRequest

PROJECT_ID = "bigtable-benchmark-lab"
INSTANCE_ID = "bt-benchmark-lab"
TABLE_ID = "benchmark-table"
TOTAL_WRITES = 100
PAYLOAD_SIZE = 512

TABLE_NAME = (
    f"projects/{PROJECT_ID}/instances/"
    f"{INSTANCE_ID}/tables/{TABLE_ID}"
)


def percentile(values, p):
    if not values:
        return None

    ordered = sorted(values)
    index = max(
        0,
        min(
            len(ordered) - 1,
            int((p / 100) * len(ordered) + 0.999999) - 1,
        ),
    )
    return round(ordered[index], 3)


def main():
    credentials, _ = google.auth.default()
    client = BigtableClient(credentials=credentials)

    latencies = []
    errors = 0

    print(f"Starting {TOTAL_WRITES} sequential Bigtable writes...", flush=True)

    benchmark_start = time.perf_counter()

    try:
        for i in range(TOTAL_WRITES):
            # Separate key prefix preserves the original benchmark rows.
            row_key = f"writebench#{i:010d}".encode()

            payload = (
                f"benchmark-write-{i:010d}".encode()
                .ljust(PAYLOAD_SIZE, b"x")
            )

            request = MutateRowsRequest(
                table_name=TABLE_NAME,
                entries=[
                    {
                        "row_key": row_key,
                        "mutations": [
                            {
                                "set_cell": {
                                    "family_name": "cf1",
                                    "column_qualifier": b"payload",
                                    "value": payload,
                                }
                            }
                        ],
                    }
                ],
            )

            write_start = time.perf_counter()

            try:
                responses = list(client.mutate_rows(request=request))

                entry_results = [
                    entry
                    for response in responses
                    for entry in response.entries
                ]

                if not entry_results or any(
                    entry.status.code != 0 for entry in entry_results
                ):
                    errors += 1
                    print(
                        f"Write {i + 1}: failed or missing response",
                        flush=True,
                    )
                else:
                    latencies.append(
                        (time.perf_counter() - write_start) * 1000
                    )

            except Exception as exc:
                errors += 1
                print(f"Write {i + 1} failed: {exc}", flush=True)

            if (i + 1) % 20 == 0:
                print(
                    f"Completed {i + 1}/{TOTAL_WRITES} writes",
                    flush=True,
                )

        elapsed = time.perf_counter() - benchmark_start
        successful = len(latencies)

        report = {
            "scenario": "direct_api_sequential_point_writes",
            "project_id": PROJECT_ID,
            "table": TABLE_NAME,
            "scheduled_writes": TOTAL_WRITES,
            "successful_writes": successful,
            "errors": errors,
            "payload_bytes_per_write": PAYLOAD_SIZE,
            "elapsed_seconds": round(elapsed, 3),
            "successful_writes_per_second": (
                round(successful / elapsed, 2) if elapsed else 0
            ),
            "average_latency_ms": (
                round(statistics.mean(latencies), 3)
                if latencies else None
            ),
            "p50_latency_ms": percentile(latencies, 50),
            "p95_latency_ms": percentile(latencies, 95),
            "p99_latency_ms": percentile(latencies, 99),
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        }

        with open("write_benchmark_report.json", "w") as file:
            json.dump(report, file, indent=2)

        print("\nWRITE BENCHMARK RESULTS")
        print(json.dumps(report, indent=2))
        print("\nReport saved to: write_benchmark_report.json")

    finally:
        client.transport.close()


if __name__ == "__main__":
    main()
