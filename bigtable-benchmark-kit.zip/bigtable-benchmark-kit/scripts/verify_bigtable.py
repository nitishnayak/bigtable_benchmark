import json
from google.cloud import bigtable

with open("seed_report.json") as f:
    report = json.load(f)

client = bigtable.Client(
    project=report["project_id"],
    admin=False,
)
table = client.instance(report["instance_id"]).table(report["table_id"])

expected_run_id = report["run_id"].encode()
count = 0
payload_ok = 0

print("Reading rows from Bigtable...", flush=True)

for row in table.read_rows():
    if not row.row_key.startswith(b"bench#"):
        continue

    cells = row.cells.get("cf1", {})
    run_cells = cells.get(b"run_id", [])
    payload_cells = cells.get(b"payload", [])

    if run_cells and run_cells[0].value == expected_run_id:
        count += 1
        if payload_cells and len(payload_cells[0].value) == 512:
            payload_ok += 1

print(f"Rows found for this run: {count}")
print(f"Rows with expected 512-byte payload: {payload_ok}")
print(f"Expected rows: {report['rows_submitted']}")

if count == report["rows_submitted"] and payload_ok == count:
    print("PASS: All seeded rows were verified.")
else:
    print("CHECK: Row count or payload validation did not match.")
